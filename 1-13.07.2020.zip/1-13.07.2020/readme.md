Sajt za pomoc oko centriranja texta : https://www.w3.org/Style/Examples/007/center.en.html ;
Youtube kanal LearnDesign u pomoci oko izrade dugmica za home :https://www.youtube.com/channel/UCWCcoBXOXpNMg0p8Qrn2l0g ;
